package enron.test

import org.apache.spark.{ SparkConf, SparkContext }

object Enron {

  def main(args: Array[String]) = {
    println("Required Args <INPUT_JSON_FILE>")
    val sConf = new SparkConf()
    val sc = new SparkContext(sConf.setAppName("Process-Enron"))
    val sqlContext = new org.apache.spark.sql.SQLContext(sc)
    val df = sqlContext.read.json(args(0))
    // average Word length
    val wl = df.select("subject").rdd.flatMap(a => a(0).toString.split(" ")).map(a => (a, a.length))
    val totalSum = sc.accumulator(0, "totalSum")
    wl.foreach(a => totalSum += a._2)
    val avg = (totalSum.value.toFloat / wl.count)
    println("Average Length of the words are :\t" + avg)
    //top 100 recipients
    val rps = df.select("cc", "recipients").rdd
    val result = rps.map(a => (a(0).toString.split(",").map(x => (x, 0.5)) ++ a(1).toString.split(",").map(x => (x, 1.0)))).flatMap(a => a).reduceByKey(_ + _).sortBy(a => a._2, false).take(100)
    println("top 100 recipients are:")
    result.foreach(a => println(a))
  }
}
